import * as React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";

export default function Personagem({ nome, imagem, especie, status, origem, genero, criacao }) {
  return (
    <Card sx={{ maxWidth: 345, margin: 2 }}>
      <CardMedia sx={{ width: 300, height: 300 }} image={imagem} title={nome} />
      <CardContent>
        <Typography gutterBottom variant="h5">{nome}</Typography>
        <Typography variant="body2" sx={{ color: "text.secondary" }}>Espécie: {especie}</Typography>
        <Typography variant="body2" sx={{ color: "text.secondary" }}>Status: {status}</Typography>
        <Typography variant="body2" sx={{ color: "text.secondary" }}>Origem: {origem}</Typography>
        <Typography variant="body2" sx={{ color: "text.secondary" }}>Gênero: {genero}</Typography>
        <Typography variant="body2" sx={{ color: "text.secondary" }}>Criação: {criacao}</Typography>
      </CardContent>
    </Card>
  );
}
