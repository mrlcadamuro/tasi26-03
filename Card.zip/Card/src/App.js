import React, { useEffect, useState } from "react";
import axios from "axios"; 
import { Container, Grid, CssBaseline, ThemeProvider, createTheme } from "@mui/material"; 
import Personagem from "./components/Personagem"; 

const tema = createTheme({
  palette: {
    mode: "dark", 
    primary: {
      main: "#ff5252", 
    },
  },
});

const App = () => {
  const [personagens, setPersonagens] = useState([]); 

  useEffect(() => {
    axios.get("https://rickandmortyapi.com/api/character")
      .then((response) => setPersonagens(response.data.results))
      .catch((error) => console.error("Erro ao buscar dados:", error));
  }, []); 

  return (
    <ThemeProvider theme={tema}>
      <CssBaseline /> 
      <Container>
        <Grid container spacing={3} justifyContent="center">
          {personagens.map((personagem) => (
            <Grid item key={personagem.id}>
              <Personagem
                nome={personagem.name}
                imagem={personagem.image}
                especie={personagem.species}
                status={personagem.status}
                origem={personagem.origin.name}
                genero={personagem.gender}
                criacao={personagem.created}
              />
            </Grid>
          ))}
        </Grid>
      </Container>
    </ThemeProvider>
  );
};

export default App;
